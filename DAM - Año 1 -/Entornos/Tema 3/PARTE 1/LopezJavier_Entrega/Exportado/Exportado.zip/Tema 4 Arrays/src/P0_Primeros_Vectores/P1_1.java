package P0_Primeros_Vectores;
/**@version Java version 9
 *@author Francisco Javier
 *@since 03/11/2021
 *@see PO_Primeros_Vectores El nombre  de la clase sería P1_1 en la cual, probamos Arrays*/

public class P1_1 {
public static void main (String [] args) {
	
	/** Se crea el primer array, en este caso, un vector
	 * 	@param arrayEjemplo	Es un Array int (Entero)
	 * 	Dicho Array posee 10 espacios*/
	
	int arrayEjemplo [] = new int [10];
	
	/** Se utiliza un bucle for para ir recorriendo el Array y visualizarlo
	 * El bucle se repetirá hasta que la nueva variable llegue al valor máximo array
	 * @param i contador del bucle for
	 * A medida que avanza el bucle se imprime en pantalla el espacio del array */
	
	for (int i=0;i<arrayEjemplo.length;i++) {
	
		arrayEjemplo[i]=i;
		System.out.println("Este es el valor "+i);
		};
	}
}
