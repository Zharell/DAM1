package P0_Primeros_Vectores;
/**@version Java version 9
 *@author Francisco Javier
 *@since 03/11/2021
 *@see PO_Primeros_Vectores El nombre  de la clase sería P1_2 en la cual, probamos Arrays
 *@param Scanner Importamos el paquete Scanner para introducir datos por teclado */
	
import java.util.Scanner;
public class P1_2 {
	public static void main (String [] args) {
		/**@param Se inicia el objeto entr como Scanner
		 *@param may, menor,cont como enteros
		 *@param myArray se crea un Array entero de 10 espacios
		 */
		Scanner entr = new Scanner(System.in);
		int may,men;
		int myArray [] = new int[10];
		int cont=0;
		/**@param do while Se utiliza para asignar valores por teclado al Array
		 * */
		do {
		System.out.println("Introduzca el valor que desea almacenar");
		myArray[cont]=entr.nextInt();
		cont++;
		} while (cont!=10);
		cont=0;
		may=myArray[cont];
		men=myArray[cont];
		/**@param do while Segundo bucle para asignar dos valores del Array a 2 variables
		 * @param may almacena el valor mayor del array
		 * @param men almacena el valor menor del array
		 * */
		do {
			if (may<myArray[cont]) {
				may=myArray[cont];
			}
			if (men>myArray[cont]) {
				men=myArray[cont];
			}
			cont++;
		} while (cont!=myArray.length);
		/**Se muestra en pantalla las variables men y may
		 *Se cierra el objeto Scanner */
		System.out.println(men);
		System.out.println(may);
		entr.close();
	}
}
