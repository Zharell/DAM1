package P0_Primeros_Vectores;
/**@version Java version 9
 *@author Francisco Javier
 *@since 03/11/2021
 *@see PO_Primeros_Vectores El nombre  de la clase sería P1_3 en la cual, probamos Arrays */
public class P1_3 {
	public static void main(String[]args) {
		/**@param may,men Variables que almacenan valores menores y mayores
		 * @param myArray se crea el array con valores predefinidos
		 * @param cont contrador que empieza con un valor 0 y va sumando 1 por cada repetición del bucle
		 * */
		int may,men;
		int cont;
		int [] myArray = {7,2,3,9,5,10,1,8,4,6};
		cont=0;
		/**Se asignan el mismo valor para ambas variables para poder inicializar el algoritmo*/
		may=myArray[cont];
		men=myArray[cont];
		/**@param do while se utiliza un bucle do while para asignar valor menor y mayor a las variables
		 * @param do while el bucle se repetirá hasta que el contador llegue al final de bucle
		 * @param cont el bucle suma 1 a cada repetición*/
		do {
			if (may<myArray[cont]) {
				may=myArray[cont];
			}
			if (men>myArray[cont]) {
				men=myArray[cont];
			}
			cont++;
		} while (cont!=myArray.length);
		/**Al finalizar el bucle se imprime el pantalla los valores de las variables
		 *@param men muestra el valor menor del array
		 *@param may muestra el valor mayor del array*/
		System.out.println(men);
		System.out.println(may);
	}
}
